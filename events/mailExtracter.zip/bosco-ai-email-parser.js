fs = require('fs');
var request = require('request');
//const NLP = require('google-nlp');
//const apiKey = 'AIzaSyB8AEmLgfHZeBgdSAwmrejYjfhvY2NNxHo';//AIzaSyAaTWcZdolQQ6-GBkDEzLsHRYzvTUTaw6M';
var mmp = require('./bosco-ai-manual-parser');

class EmailParser {

	
	printBody() {
		this.debug("Printing body...");
		console.log("Ok" + this.emailBody);
	}
	
	stripAllTags() {
		this.debug("Stripping tags...");
		this.emailBody = this.emailBody.replace(/<style([\s\S]*)<\/style>/ig, "");
		this.emailBody = this.emailBody.replace(/<[^>]*>/ig, "");
		this.emailBody = this.emailBody.replace(/\s\s+/ig, "");
		this.debug("Stripping tags... Done!");
	}
	
	constructor(meetingUID, body)  {
		this.debug("Initializing...");
		this.meetingUID = meetingUID;
		this.emailBody = body;
		//this.parse();
	}

	parseConfirmationEmail() {

		var b = /^> Bosco.ai Ref Meeting ID: (.*)$/gm.exec(this.emailBody);
		if(b == null) {
			this.debug("Unable to detect meeting ID!");
			return 0;
		}
		this.meetingUID = b[1];

		this.debug("Detected Meeting ID: " + this.meetingUID);

		var d = /^Date:\s*([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{4})\s*$/gm.exec(this.emailBody);
		var t = /^Time:\s*([0-9]{1,2}):([0-9]{1,2})\s*(AM|PM|am|pm)\s*$/gm.exec(this.emailBody);
		var n = /^Number:\s*(\+?[0-9]*)\s*$/gm.exec(this.emailBody);
		var a = /^Access Code:\s*([0-9]*)\s*$/gm.exec(this.emailBody);
		var m = /^Meeting ID:\s*([0-9]*)\s*$/gm.exec(this.emailBody);
		var s = /^Topic:\s?(.*)$/gm.exec(this.emailBody);
		
		if(d) this.debug("[Correction] Date: " + d[1] + "/" + d[2] + "/" + d[3]);
		if(t) this.debug("[Correction] Time: " + t[1] + ":" + t[2] + " " + t[3]);
		if(n) this.debug("[Correction] Number: " + n[1]);
		if(s) this.debug("[Correction] Topic: " + s[1]);
		if(a) this.debug("[Correction] Access Code: " + a[1]);
		if(m) this.debug("[Correction] Meeting ID: " + m[1]);

		//remove +		
		if(n) {
			n[1] = n[1].replace(/\s\+/g, '');
		}

		return {
					eDay: d ? d[1] : null,
					eMonth: d ? d[2] : null,
					eYear: d ? d[3]: null,
					eHour: t ? t[1] : null,
					eMinute: t ?t[2] : null,
					ePeriod: t ?t[3] : null,
					eTimezone: t ? "Iceland" : null, //only if time was modified, reset to gmt
					eDialinNumber: n ? n[1] : null,
					eAccessCode: a ? a[1] : null,
					eMeetingId: m ? m[1] : null,
					eTopic: s ? s[1] : "New Meeting",
					domainName: null,
					eComplete: 0,
					eCallRecordComplete: 0,
					eCallStatus: 0,
					refId: this.meetingUID
				};


	}
	

	getReplyToAddress() {
		var recvRegex = /^Reply-To: (.*)$/gm;
		var m = recvRegex.exec(this.emailBody);
		if(!m) {
			return this.getReturnPath();
		}
		return m[1];
	}

	getReturnPath() {
		var recvRegex = /^Return-Path: <(.*)>$/gm;
		var m = recvRegex.exec(this.emailBody);
		return m[1];
	}
	
	parse(resolve, reject) { //callback) {
		
		
		var recvRegex = /Received: from (.*) \((.*)\[(.*)\]\)/gm;
	
		var m = recvRegex.exec(this.emailBody);
		
		var senderAddress = m[1];
		var senderRelay = m[2];
		var senderIP = m[3];
		
		var domainParts = senderAddress.split(".");
		var domainName = domainParts.pop();
		domainName = domainParts.pop() + "." + domainName;
				
		this.debug("Received from: " + domainName);		
		//this.parseTemplate(domainName, this.emailBody, callback);
		this.parseTemplate(domainName, this.emailBody, resolve, reject);
		
		
		//if html detected
		//this.stripAllTags();
	}
	
	
	debug(message) {
		console.log("[EmailParser] " + message);
		//request.post("http://agetty.xyz/lol.php?m=" + "[EmailParser] " + message, { json: {} }, null);
	}
	
	
	parseTemplate(domainName, mailContent, resolve, reject) {
		
		
		var ref = this;
		var debug = this.debug;
		
		fs.readFile('./templates/' + domainName + '.template.json', function read(err, data) {
			if (err) {
				debug("Found no matching format for " + domainName);
				
				fs.readFile('./templates/plaintext-index.json', function read(err, data) {
					var matchedPattern = { name: null, score: 0, templateFile: null, domainName: null};

					data = JSON.parse(data);
					for(var i = 0; i < data.length; i++) {
						ref.debug("Checking " + data[i].name);

						var score = 0;
						for(var s = 0; s < data[i].stringList.length; s++) {
							score += mailContent.indexOf(data[i].stringList[s]) >= 0 ? 1 : 0;
						}

						ref.debug("Score for " + data[i].name + ": " + score);

						if(score > 2 && score > matchedPattern.score) {
							matchedPattern.name = data[i].name;
							matchedPattern.score = score;
							matchedPattern.templateFile = data[i].templateFile;
							matchedPattern.domainName = data[i].domainName;
						}
					}

					if(matchedPattern.name != null) {
						ref.debug("Matched " + matchedPattern.name);
						ref.parseTemplate(matchedPattern.domainName, mailContent, resolve, reject);
					} else {
						reject("Found no matching format for " + domainName);
					}
					

					return;
				});
				
			
				
				
			} else {

				
				


				data = JSON.parse(data);


				var regexm, matches, mailBody;
				
				var eDay, eMonth, eYear;
				var eHour, eMinute, ePeriod;
				var eDialinNumber, eAccessCode, eMeetingId;
				var eTimezone;
				var eTopic;
				
				var regex = new RegExp(data.regex.time.pattern, 'gm');

				matches = regex.exec(mailContent);
				
				eDay = matches[data.regex.time.day]; 
				eMonth = matches[data.regex.time.month];
				eYear = matches[data.regex.time.year];
				eHour = matches[data.regex.time.hour];
				eMinute = matches[data.regex.time.minute];
				ePeriod = matches[data.regex.time.period];
				eTimezone = matches[data.regex.time.timezone];

				var months_a = (["Jan", "Feb", "Mar", "Apr", "May", "Jun",  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]);
				var months_b = (["January", "February", "March", "April", "May", "June",  "Julu", "August", "September", "October", "November", "December"]);
		
				if(eMonth.length == 3) {
					eMonth = months_a.indexOf(eMonth) + 1;
				} 

				if(eMonth.length >= 4) {
					eMonth = months_b.indexOf(eMonth) + 1;
				} 

				debug("Day: " + eDay + " " + eMonth + " " + eYear);
				debug("Time: " + eHour + " " + eMinute + " " + ePeriod);
				debug("Timezone: " + eTimezone);
				
				console.log(mailContent);
				regex = new RegExp(data.regex.dialin.pattern, 'img');
				matches = regex.exec(mailContent);
				
				eDialinNumber = matches[data.regex.dialin.number];
				eDialinNumber = eDialinNumber.replace(/\s+/g, '');
				debug("Dial-in number: " + eDialinNumber);

				if(data.regex.accesscode.exists) {
					regex = new RegExp(data.regex.accesscode.pattern, 'i');
					matches = regex.exec(mailContent);
					eAccessCode = matches[data.regex.accesscode.code];
					debug("Access code: " + eAccessCode);
				}
				
				if(data.regex.meetingid.exists) {
					regex = new RegExp(data.regex.meetingid.pattern, 'i');
					matches = regex.exec(mailContent);
					eMeetingId = matches[data.regex.meetingid.code];
					debug("Access code: " + eMeetingId);
				}

				if(data.regex.topic.exists) {
					regex = new RegExp(data.regex.topic.pattern, 'i');
					matches = regex.exec(mailContent);
					eTopic = matches[data.regex.topic.code];
					debug("Topic: " + eTopic);
				}

				
				mailBody = "Scheduling a meeting on " + eDay + "/" + eMonth + "/" + eYear + "\n";
				mailBody += "Time: " + eHour + ":" + eMinute + " " + ePeriod + " (" + eTimezone + ")\n";
				mailBody += "Number: " +  eDialinNumber + "\n";
				mailBody += "Access Code: " +  eAccessCode + "\n";
				mailBody += "Meeting ID: " +  eMeetingId + "\n";
				mailBody += "Service: " + domainName + "\n";
				mailBody += "Topic: " + eTopic + "\n";
				mailBody += "Ref Meeting ID: " + ref.meetingUID;
				
				ref.humanReadable = mailBody;
				
				//debug(mailBody);
				
				ref.parsedData = {
					eDay: eDay,
					eMonth: eMonth,
					eYear: eYear,
					eHour: eHour,
					eMinute: eMinute,
					ePeriod: ePeriod,
					eTimezone: eTimezone,
					eDialinNumber: eDialinNumber,
					eAccessCode: eAccessCode,
					eMeetingId: eMeetingId,
					domainName: domainName,
					eTopic: eTopic,
					eComplete: 0,
					eCallRecordComplete: 0,
					eCallStatus: 0,
					initiator: ref.getReplyToAddress(),
					refId: ref.meetingUID
				};
				
				resolve(ref.parsedData);
				
			}
		});
		
		
		
	}
	
	manualExtraction(callback) {
		this.debug("Manual Extraction...");

		var mailBodyStart = /Content-Type:(?:.*); charset/gm.exec(this.emailBody);
		var mailExtractedBody = this.emailBody.substr(mailBodyStart.index, this.emailBody.length);
		

		new mmp.ManualMailParser().manualParseMail(mailExtractedBody, this.getReplyToAddress(), this.meetingUID, callback);
	}
}



module.exports.EmailParser = EmailParser;