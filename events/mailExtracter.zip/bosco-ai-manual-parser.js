
//const NLP = require('google-nlp');
var request = require('request');
const apiKey = 'AIzaSyAaTWcZdolQQ6-GBkDEzLsHRYzvTUTaw6M';

class ManualMailParser {

    constructor() {

    }

    manualParseMail(text, initiatorEmail, meetingUID, completeCallback) {
		var rawText = text;
        text = text.replace(/\r?\n/gm, " ");
		var textLower = text.toLowerCase();
        console.log(text); 
        //return;

		var parsedData = {
						eDay: 0,
						eMonth: 0,
						eYear: 0,
						eHour: 0,
						eMinute: 0,
						ePeriod: 0,
						eTimezone: 0,
						eDialinNumber: 0,
						eAccessCode: 0,
						domainName: "Unknown",
						eTopic: "New Meeting",
						eComplete: 0,
						eCallRecordComplete: 0,
						eCallStatus: 0,
						initiator: initiatorEmail,
						refId: meetingUID
		};

		var dateRegex = [
			{regex: /(\d{1,2})(?:th|rd|st)?\s(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|(Nov|Dec)(?:ember)?),?\s(\d{4})/gm, eDay: 1, eMonth: 2, eYear: 4 },              // (25)th January 2017
			{regex: /(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|(Nov|Dec)(?:ember)?)\s(\d{1,2})(?:th|rd|st)?,?\s(\d{4})/gm, eDay: 3, eMonth: 1, eYear: 4},              // January 25(th) 2017.
			{regex: /(\d{1,2})[-|\/|\.](\d{1,2})[-|\/|\.](\d{4})/gm, eDay: 1, eMonth: 2, eYear: 3}                                                                                                                                          //  dd -/. mm -/. yyyy
		];

		var months_a = (["Jan", "Feb", "Mar", "Apr", "May", "Jun",  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]);
		var months_b = (["January", "February", "March", "April", "May", "June",  "Julu", "August", "September", "October", "November", "December"]);


		var date = null;
		var dateFormat = 0;
		for(dateFormat = 0; dateFormat < dateRegex.length; dateFormat++) {
			date = this.retrieveRegexMatches(dateRegex[dateFormat].regex, text);
			if(!date.length) continue;
			console.log("Date Format #" + dateFormat + " matched.");
			break;
		}
		

		if(date != null && typeof date !== 'undefined' && date.length > 0)  {
			console.log("Possible date: " + date[0][dateRegex[dateFormat].eDay] + " " + date[0][dateRegex[dateFormat].eMonth] + " " + date[0][dateRegex[dateFormat].eYear]);

			parsedData.eDay = date[0][dateRegex[dateFormat].eDay];
			parsedData.eMonth = date[0][dateRegex[dateFormat].eMonth];
			parsedData.eYear = date[0][dateRegex[dateFormat].eYear];

			if(parsedData.eMonth.length == 3) {
				parsedData.eMonth = months_a.indexOf(parsedData.eMonth) + 1;
			} 

			if(parsedData.eMonth.length >= 4) {
				parsedData.eMonth = months_b.indexOf(parsedData.eMonth) + 1;
			} 
			
		}

		var timeRegex = [ /(\d{1,2})((:|.)(\d{2}))?\s?(AM|PM|am|pm)/gm, /(\d{1,2})(:|.)(\d{2})/gm ];
		var timeRegexIndexes = [{ eHour: 1, eMinute: 4, ePeriod: 5}, { eHour: 1, eMinute: 3, ePeriod: null}];


		var time = null;
		var timeFormatId = 0;
		for(timeFormatId = 0; timeFormatId < timeRegex.length; timeFormatId++) {
			time = this.retrieveRegexMatches(timeRegex[timeFormatId], text);
			console.log("Detected time: " + time[0]);
			if(time.length > 0) break;
		}
		console.log("Detected Time format #" + timeFormatId);
		

		if(time != null && typeof time !== 'undefined' && time.length > 0) {
			console.log("Possible Time: " + time[0][timeRegexIndexes[timeFormatId].eHour] + " " +  time[0][timeRegexIndexes[timeFormatId].eMinute] + " " +  time[0][timeRegexIndexes[timeFormatId].ePeriod]);

			parsedData.eHour = time[0][timeRegexIndexes[timeFormatId].eHour];
			parsedData.eMinute = typeof time[0][timeRegexIndexes[timeFormatId].eMinute] === 'undefined' ? 0 : time[0][timeRegexIndexes[timeFormatId].eMinute];
			parsedData.ePeriod = time[0][timeRegexIndexes[timeFormatId].ePeriod];

            if(timeFormatId == 1) {
                if(parsedData.eHour > 12) {
				     parsedData.eHour =  parsedData.eHour - 12;
					 parsedData.ePeriod = "PM";
				}
                else parsedData.ePeriod = "AM";
           	} else {
				   if(parsedData.eHour > 12) {
				     	parsedData.eHour =  parsedData.eHour - 12;
				   }
			}
		}


		var topicRegex = [/(?:Sub|Subject|Topic)\s?:\s?([ \w\d]*)/igm]; //[ /(?:Sub|Subject|Topic)\s?:\s?(.*)$/igm, /(?:Sub|Subject|Topic)\s?:\s?([a-zA-Z\s]*)\.$/igm ];
		var topicRegexIndex = 1;
		var topic = null;

		var topicFormatId = 0;
		for(topicFormatId = 0; topicFormatId < topicRegex.length; topicFormatId++) {
			topic = this.retrieveRegexMatches(topicRegex[topicFormatId], rawText); //Pattern matching on `rawText` here, since `text` has all newline characters removed.
			if(topic.length > 0) {
				console.log("Detected topic: " + topic[0][1] );
				parsedData.eTopic = topic[0][1];
				break;
			}
		}


		


		var numericalValues  = this.retrieveRegexMatches(/((\d+\s?\-?)+)/gm, text, null);
	
		var proximityStrings = {
				phone: ["dial", "call", "join", "dial-", "dial in", "phone number", "dial-in number", "toll", "toll free"],
           		access: ["access", "code", "access code", "access-code", "password", "pin"],
            	meetingid: ["meeting id", "id"]
		}
		

		var finalPhone = {value: 0, confidence: 0}, 
			finalAccessCode = {value: 0, confidence: 0}, 
			finalMeetingId = {value: 0, confidence: 0};

		for(var i = 0; i < numericalValues.length; i++) {
			var match = numericalValues[i][0];
			var pos = numericalValues[i].index;

			var phoneConfidence = 0;
			var accessCodeConfidence = 0; 
			var meetingIdConfidence = 0;

			//Use lowercase text input here..

			for(var p = 0; p < proximityStrings.phone.length; p++) {
				var psIndex = textLower.indexOf(proximityStrings.phone[p]);
				var confidence = Math.abs(psIndex - pos)
				if(confidence < 16) phoneConfidence += 16 - confidence;
			}

			for(var p = 0; p < proximityStrings.access.length; p++) {
				var psIndex = textLower.indexOf(proximityStrings.access[p]);
				var confidence = Math.abs(psIndex - pos)
				if(confidence < 16) accessCodeConfidence += 16 - confidence;
			}

			for(var p = 0; p < proximityStrings.meetingid.length; p++) {
				var psIndex = textLower.indexOf(proximityStrings.meetingid[p]);
				var confidence = Math.abs(psIndex - pos)
				if(confidence < 16) meetingIdConfidence += 16 - confidence;
			}

			
			var detected = {type: null, confidence: 0};
			if(phoneConfidence != 0) detected = {type: 'phone', confidence: phoneConfidence};
			if(accessCodeConfidence != 0 && accessCodeConfidence > detected.confidence) detected = {type: 'accesscode', confidence: accessCodeConfidence};
			if(meetingIdConfidence != 0 && meetingIdConfidence > detected.confidence) detected = {type: 'meetingid', confidence: meetingIdConfidence};

			if(detected.type) {
				console.log("String: " + match + ". Detected: " + detected.type + " (" + detected.confidence*10 + "% confidence)");
				switch(detected.type) {
					case 'phone': 
						if(detected.confidence > finalPhone.confidence) {
							finalPhone.value = match;
							finalPhone.confidence = detected.confidence;
						}
						break;
						
					case 'accesscode':
						if(detected.confidence > finalAccessCode.confidence) {
							finalAccessCode.value = match;
							finalAccessCode.confidence = detected.confidence;
						}
						break;
					case 'meetingid': 
						if(detected.confidence > finalMeetingId.confidence) {
							finalMeetingId.value = match;
							finalMeetingId.confidence = detected.confidence;
						}
						break;
				}
			} 

        
		

		}


		
		parsedData.eDialinNumber = finalPhone.value;
		parsedData.eDialinNumber = parsedData.eDialinNumber.replace(/\s+/g, '');
		parsedData.eDialinNumber = parsedData.eDialinNumber.replace(/\-/g, '');
		parsedData.eAccessCode = finalAccessCode.value;
		parsedData.eMeetingId = finalMeetingId.value;

        //This is done to.. give proper input to google npl, it doesn't seem to detect words when coupled with punctuation, symbols..
		var tokens = text.split(" ");
		var csvString = "";
		for(var x = 0; x < tokens.length; x++) {
			tokens[x] = tokens[x].replace(/\W/gm, "");
			csvString += tokens[x] + ', ';
		}

		var ref=this;
        //If time was never detected, skip searching for timzeones..
        if(time != null && typeof time !== 'undefined' && time.length > 0) {
            request.post("https://language.googleapis.com/v1beta2/documents:analyzeEntities?key=AIzaSyB8AEmLgfHZeBgdSAwmrejYjfhvY2NNxHo",
			{ json: {
					"document": {
						"type":"PLAIN_TEXT",
						"language": "EN",
						"content": csvString
					},
					"encodingType":"UTF8",
				} 
			},
			function (error, response, body) {

					if (!error && response.statusCode == 200) {
					
						var entities = body;
						var detectedTimezone = { zone: "Iceland", confidence: 0};
						parsedData.eTimezone = detectedTimezone.zone;

						if(entities.entities.length == 0 || !entities || !entities.entities ) {
							
							completeCallback(parsedData);
						}

						for(var e in entities.entities) {
							if(entities.entities[e].type == ("LOCATION")) {
								var posInText = text.indexOf(entities.entities[e].name);
								var timezoneProximity = Math.abs(time[0].index - posInText);
								var timezoneConfidence =  (20 - timezoneProximity);

								console.log("Detected Location: " + entities.entities[e].name + " Confidence: " + timezoneConfidence) ;
								
								
								if(timezoneConfidence > detectedTimezone.confidence) {
									detectedTimezone.zone = entities.entities[e].name;
									detectedTimezone.confidence = timezoneConfidence;
									parsedData.eTimezone = entities.entities[e].name;
								}
							} 
						}
						completeCallback(parsedData);


					} else {
						console.log(body);
						console.log("Unable to connect to google NLP!");
						parsedData.eTimezone = "Iceland";
            			completeCallback(parsedData);
					}
				}
			);
		} else {
            //Return
            parsedData.eTimezone = "Iceland";
            completeCallback(parsedData);
        }
			
			/*let nlp = new NLP( apiKey );
		    nlp.analyzeEntities(csvString)

			.then((entities) => {
                
                var detectedTimezone = { zone: "Iceland", confidence: 0};
                parsedData.eTimezone = detectedTimezone.zone;

				if(entities.entities.length == 0 || !entities || !entities.entities ) {
					
					completeCallback(parsedData);
				}

				for(var e in entities.entities) {
					if(entities.entities[e].type == ("LOCATION")) {
                        var posInText = text.indexOf(entities.entities[e].name);
                        var timezoneProximity = Math.abs(time[0].index - posInText);
                        var timezoneConfidence =  (20 - timezoneProximity);

						console.log("Detected Location: " + entities.entities[e].name + " Confidence: " + timezoneConfidence) ;
						
                        
                        if(timezoneConfidence > detectedTimezone.confidence) {
                            detectedTimezone.zone = entities.entities[e].name;
                            detectedTimezone.confidence = timezoneConfidence;
                            parsedData.eTimezone = entities.entities[e].name;
                        }
					} 
				}
                completeCallback(parsedData);
			})
			.catch((error) => {
				console.log(error);
			})
			*/
        

		
	}

    retrieveRegexMatches(regex, str) {
		var matchList = [];
		var m;
		while ((m = regex.exec(str)) !== null) {
			if (m.index === regex.lastIndex) {
				regex.lastIndex++;
			}
		
			matchList.push(m);
		}
		return matchList;
	}
}


module.exports.ManualMailParser = ManualMailParser;